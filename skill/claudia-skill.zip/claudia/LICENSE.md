# Use her

Claudia is an open character. What you can do with her and the images here, and what isn't covered.


Claudia is an open character. Make images, videos, songs, stories, games or merch with her, commercial or not. Use the
images on this site as references, as image prompts, or as material. You don't need to ask. A credit ("Claudia by
anabology") is appreciated, not required.

## What helps

- **Keep her herself.** The [canon](https://claudia.gallery/claudia/) is short: the black bob, one clay streak, the star clip, the mic, an
  adult face. Change everything else.
- **Make her an adult, always.** She is in her late twenties. Nothing that reads under-age, and nothing explicit.
- **Say what's generated.** All three films were made with Midjourney, Seedance, Suno and Claude, and said so.

## Songs with her

She is open to musicians the way Hatsune Miku is open to producers: make songs with her and release them. A few norms
keep it clean for everyone.

- **Release under your own name.** You are the artist. Never upload as "anabology": that is the director's artist
  profile, and anything released there reads as theirs. Don't present a release as an official Claudia or anabology
  release.
- **Leave "feat. Claudia" out of the artist field.** Streaming services match artist names to profiles, so a "Claudia"
  credit merges into unrelated artists already called Claudia, or creates a profile that whoever claims it controls.
- **Credit her in the description and on the cover:** "Claudia is an open character by anabology (claudia.gallery)".
- **If any of it is AI-made, say so.** Vocals, music or lyrics: distributors ask, and the services label it. Human-made
  work needs no label. For AI tools, check the terms for commercial release (Suno, for one, requires a paid plan at the
  time you make the song).
- **Make your own songs.** Don't re-release the songs of ESCAPE VELOCITY, CLODYSSEY or BLISS, or their stems.
- **One place for fan tracks:** a fan-run playlist works better than a shared artist profile, because nobody has to own it.

## What isn't covered

- **Other people's things in the films.** The Bliss photograph and the XP sounds belong to Microsoft. Real public figures
  appear in CLODYSSEY only as posts labelled AI IMAGE; they are not part of this gallery. The anime idol in CLODYSSEY is
  another creator's character.
- **Anthropic.** Claudia is fan work about Claude. She is not affiliated with or endorsed by Anthropic, and Anthropic's
  names and marks are theirs.
- **The director's accounts.** The Midjourney profile and the Suno Voice used in the films live in personal accounts and
  can't be shared. Everything they made is here.

## Credits

Directed by **anabology**. Made with **Claude** (Anthropic's model, in Claude Code) as the production team, **Midjourney**
v8.2 for every image, **Seedance 2.5** for the moving shots and **Suno** v6 for the songs. This site was built by Claude
from the films' own records.

Type: TeX Gyre Heros (GUST Font License), DINish (SIL Open Font License), IBM Plex Mono (SIL Open Font License).
Player: hls.js (Apache 2.0).
