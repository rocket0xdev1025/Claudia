# The song

How her songs were written and made in Suno: lyrics that land in one listen, verse lines that flow, the style fields, and her voice.


Each film starts from its song, and the song starts from the lyric. All three were made in Suno v6 in custom mode, from
lyrics written with Claude and checked with a scansion scorer, then picked by ear by the director. The video runs the
full length of the song and is timed to it word by word.

## Lyrics before anything else

The rules, each learned from a rejected draft:

- **The topic is obvious in the first two lines.** CLODYSSEY's first draft was rejected because "i dont get from verse 1
  what the topic is really". Name the big moments people actually saw, or tell a story (CLODYSSEY's AI narrates "your"
  September in the second person).
- **Every reference lands in one listen.** Obscure studies and insider trivia go into the video's graphics, not the lyric.
- **A sequel never reuses the last song's device.** No second countdown after ESCAPE VELOCITY's "18 months", no numbered
  looks, no reused call-and-response shape. BLISS reused none of the first two films' devices.
- **Subtracting beats adding.**
- **Never touch a line the director has locked.**

## Verse lines that flow

Suno sets each spoken verse line in its own two-bar slot: it comes in on the "and" of beat 2 and lands the last word on
beat 4 of bar 2, speaking at a natural rhythm stretched to fit. So:

- write **natural sentences of 10–13 syllables**, with the important words where speech already stresses them;
- **rhyme couplets on the last word** to mark the bar ends;
- keep short fragments for deliberate punches only. Lines of 5–8 syllables get dragged into choppy fragments, and a list
  of names reads as a roll call.

Optimising every stress onto the beat made one CLODYSSEY draft worse. The director: "perfect beat precision without
attention to what words land where doesnt lead to this being great … let there be a creative groove".

## Two numbers

A lyric gets two scores, per section and for the song: **scansion** (how the words sit on the grid as Suno sings them)
and **assonance** (whether line ends ring: a rhyme, a slant rhyme or shared vowels within four lines). Measured on the
finished songs:

| Song | Scansion | Assonance |
|---|---|---|
| ESCAPE VELOCITY | 75 | 39 |
| CLODYSSEY | 83 | 55 |
| BLISS | 80 | 43 |

Every sung couplet should ring. Spoken, deadpan lines can stay unrhymed. Scores don't replace hearing it: make a take.
How the scorer works, so you can build one: [What to build](https://claudia.gallery/wiki/toolkit/#2-the-lyric-scorer-scansion-and-assonance).

## Hooks off the beat

A hook that lands in a stop should be syncopated. The director on BLISS: "the 'would you like help?' would land much
better if syncopated". Write the off-beat accent into the lyric sheet and the Suno direction.

## Key

If the film has a sound palette, the song goes in its key. XP's Startup and Shutdown chords resolve in E-flat major, so
BLISS's styles asked for "C minor verses lifting to E-flat major choruses", and most of the real XP sounds sat in the mix
without pitch-shifting. The director's note for next time: "match the key of the music to the palette of windows sounds
(E-flat major for both the startup and shutdown sounds!)".

## The style fields

**ESCAPE VELOCITY**, Suno v6:

```prompt
fashion show electroclash techno, 128 BPM, 4/4, dry analog kick, rolling acid bassline, cold detuned synth stabs, sweeping orchestral strings on the builds, deadpan female spoken-word verses, close and dry, clipped and confident, every word crisp and intelligible, euphoric sung female trance chorus with a supersaw lift and big clear vowels, crowd call-and-response shouts, stacked chanted vocals in the drop, a key change up into the last chorus, catwalk energy, cold, luxurious, optimistic, Berlin minimal austerity, clean modern mix
```

Exclude: `rap, rock guitar, lo-fi, male lead vocal, mumbled vocals, big room EDM, dubstep`

**CLODYSSEY**, EV's style with whispered asides, a siren synth and no strings:

```prompt
Electroclash techno, clean modern mix with close, dry vocals; deadpan, clipped female spoken verses with intimate whispered asides rise into euphoric sung choruses answered by stacked crowd shouts; dry analog kick, rolling acid bassline, cold detuned synth stabs, a rising siren synth on the builds, hardgroove percussion in the break, supersaw chorus lift; 128 BPM hypnotic 4/4 pulse, key change up into the final chorus
```

Exclude: `rap, rock guitar, lo-fi, male lead vocal, mumbled vocals, big room EDM, dubstep, strings, orchestral strings`

**BLISS**, the winning style ("P3"), UK garage verses into trance choruses:

```prompt
Bouncy UK garage into euphoric trance, 130 BPM, C minor verses lifting to E-flat major choruses, a turn-of-the-millennium sound with a crisp modern mix. Verses ride a shuffled 2-step beat with skippy kicks, swung hats, rimshots and a warm sub bass; choruses switch to a four-on-the-floor kick with soft supersaw pads, a bright plucked arpeggio and glassy bell chimes. Verses: playful, close, warm female spoken voice, smiling and conversational, every word crisp. Choruses: euphoric sung female lead with open vowels and crystalline, breathy stacked harmonies. Stop-time gaps where the beat cuts out for half a bar, a filter build into each chorus, a key change up for the final chorus. Sunny, nostalgic, light on its feet, never harsh.
```

Keep brand and artist names out of the style field: Suno strips artist names and can block a generation over trademarks.
Describe the sound instead ("ethereal progressive house, long evolving pads" rather than an artist).

## Her voice

The same singer runs through all three: deadpan, clipped spoken verses rising into euphoric sung choruses, close and dry,
every word crisp. For CLODYSSEY and BLISS the agent-made takes used a Suno Voice built from ESCAPE VELOCITY's vocal
(Library → Voices → create from a song in your library; one Voice per song). The director's final takes of CLODYSSEY and
BLISS were their own generations on Suno's v6-wild model. Try takes without the Voice too; a Voice is not required for her
to sound like her, and it lives only in its maker's account.

## Pronunciation and cues

- **Spell numbers and acronyms out** in the lyrics field ("A G I", "C S I") so Suno says them.
- **Respell names it gets wrong:** "Dario" came out d-AIR-ee-oh and was written "Dahrio".
- **Section cues** in square brackets, each on its own line (`[Verse 1 - spoken, deadpan]`). Parentheses get sung.
- **Cues steer the arrangement:** "darker, the bass drops out" made a CLODYSSEY verse punchier.

## Takes

Generate many and pick by ear; a strong style with a weak take still loses. CLODYSSEY ran eleven rounds and 50 agent
takes before the director made the final take themselves; BLISS ran three rounds and 16 takes, and again the director's own
take won. Keep every round's lyric, style and verdict in a takes log.

## Listening to it

Before anything is boarded, the song gets analysed: stems (htdemucs), a beat map, a start and end time for every word
(forced alignment), and a list of hits (kicks, snares, risers, drops) for the edit to land on.

- **Suno takes speed up.** ESCAPE VELOCITY went from 131.5 to 133.9 BPM and CLODYSSEY from 129 to 132: use a beat map,
  never a fixed BPM.
- **Put the grid on the kick.** BLISS's first beat grid sat on the hi-hats, 0.214 s early; every cut would have landed just
  before the beat.
- **Check word times by ear.** A delay throw got aligned as a word in ESCAPE VELOCITY, 2.6 s early.
- **Map a new mix before swapping it in.** An export from Suno's editor came back re-timed by up to 0.7 s; align it to the
  original by spectrogram first.

The full song records, with every draft and take:
[ESCAPE VELOCITY](https://claudia.gallery/record/escape-velocity/prompts-suno/) ·
[CLODYSSEY](https://claudia.gallery/record/clodyssey/prompts-suno/) ·
[BLISS](https://claudia.gallery/record/bliss/prompts-suno/).

## Releasing a song

Release under your own name, never as "anabology", and leave "feat. Claudia" out of the artist field. Credit her in the
description: "Claudia is an open character by anabology (claudia.gallery)". If any of it is AI-made, say so; human-made
work needs no label. The norms in full: [Songs with her](https://claudia.gallery/use/#songs-with-her).


---
From the Claudia wiki: https://claudia.gallery/wiki/song/
