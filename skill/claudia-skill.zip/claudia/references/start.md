# Start here

Making a music video with her from nothing: what you are making, the scale to pick, the accounts, the six checkpoints where a person decides, the rules for spending, and what to build first.


The three films were made by one director and Claude, with tools written along the way. This page is the way in for
anyone starting their own film with Claudia, and for the agent helping them: the bar, what to set up, where a person
has to look and decide, and what to build. The tools are specified in [What to build](https://claudia.gallery/wiki/toolkit/). This page
assumes you have none of them yet.

## What you are making

A lyric music video: a song, Claudia singing it, and a layer of motion design drawn in code over the footage. Five
things carry the quality:

1. **Every sung word is on screen when it is sung**, at its measured time. A check counts them, and it must print N of
   N.
2. **Every lyric line gets a graphic that explains it**: the chart a number implies, the label, the diagram, the
   counter. Animated lyrics alone are not the product. The director: "not just animated lyrics but things that fit the
   words being said … almost explaining the words with visuals".
3. **A through-line device carried by every shot**: ESCAPE VELOCITY's split-flap countdown, CLODYSSEY's safety card and
   rope-load readout, BLISS's XP desktop. It makes a hundred shots read as one object.
4. **Measured, not eyeballed.** Word times come from forced alignment checked by ear, cuts from a beat map, lip sync
   from comparing audio, and spend from the provider's bill.
5. **A person's attention is spent at six checkpoints.** Everything between them runs without asking.

## Two roles

The **director** is a person. They own the taste, the money and the six checkpoints, and they say it in very few
words: ESCAPE VELOCITY took about 50 notes, BLISS 21. The **production** is an agent, or several. It does the research,
the lyrics, the board, every prompt, every script, the edit and every frame of motion design.

How the production talks to the director:

- **At a checkpoint:** show one artefact and ask one question with a default ("Which one? Default: A."). Record the
  answer word for word and dated in a decisions log. A later decision is added as a new entry that supersedes the old
  one; never edit the old one.
- **Between checkpoints:** ping the director only when a paid service fails, a step needs a person (a captcha, a
  sign-in, a download), or a decision is theirs (taste, money, a real person's likeness). ESCAPE VELOCITY's director:
  "only time to ping me is if higgsfield fails."
- **Send pictures, not descriptions:** contact sheets, numbered stills, a five-second proof. The director judges by eye,
  fast, one line per take.

## Pick a scale

| | Quick | Studio | Full |
|---|---|---|---|
| You need | an agent, an image model, your own song or an AI song model | + Midjourney, Suno, Seedance 2.5 credits | + an agent plan that can run multi-agent workflows for a day or two |
| Song | your upload, or a short generated song | Suno, auditioned round by round | Suno, with a lyric loop scored for scansion and assonance |
| Stills | images from an API | Midjourney | Midjourney |
| Motion | 2.5D plates, a few cheap clips | sung clips with measured lip sync, covers | chains of sung clips, scripted motion clips, covers |
| Board | about 14 shots a minute, drafted automatically | about 20 a minute, one pass | about 27 a minute; several boards judged and merged |
| Motion design | a default renderer driven by data | the default renderer plus one graphic per line | bespoke code per chapter, reviewed on rendered frames |
| Video spend | $3–20 | $50–110 | $90–250 (the films, measured) |
| Time | 2–6 hours (estimate) | 1–2 days (estimate) | 19–41 hours of wall-clock (the films, measured) |

- When unsure, start Quick. Every file carries over to a bigger scale.
- A lead who sings on camera with real lip sync, or your own Midjourney look, needs Studio at least.
- Bespoke graphics for every line and 90–140 shots need Full. The films used 1.4–2.4 billion tokens each, 96–98% of
  them prompt-cache re-reads.
- Generated songs run about 2–3 minutes in one take. Anything longer needs Suno.

## Accounts and keys

| What | For | Notes |
|---|---|---|
| Suno, on a paid plan | the song | There is no API, and the terms forbid bots: a person presses Create and downloads the WAV. Downloading on a paid plan is what allows commercial use. Read the current terms before you monetise. |
| Midjourney | the plates | v8.2, `--raw --hd`. A personal style profile is yours alone: never publish its code. |
| Seedance 2.5 | moving shots | Via OpenRouter: about $0.23 a second at 720p, $0.10 at 480p. Via Higgsfield: 3, 7 or 12 credits a second at 480p, 720p or 1080p. Give the API key its own spend limit, set above the project cap. |
| An image-edit model | fixing a plate at the source, adding people to a set | about $0.14 an edit (Gemini 3 Pro Image) |
| A transcription model | checking the words the take actually sings | about $0.002 a song |
| A coding agent | the production | Claude Code made the films. |
| A GPU (optional) | stems, alignment, depth maps, detection | Saves minutes, not money: stems and alignment of a 5-minute song took 41 s on an RTX 3090 Ti and 126 s on 8 CPU threads. |

Prices are from autumn 2026.

**Secrets:** keys live in environment variables or a gitignored file, never in a chat, a prompt, a log or a commit. The
agent never types the person's passwords. Captchas, two-factor prompts and sign-ins go to the person. A key pasted into
a chat is burned: revoke it and make a new one.

## The order of work

| # | Stage | Output | Checkpoint |
|---|---|---|---|
| 1 | Brief and taste | the ask, verbatim; the look, accent, density and taboos | |
| 2 | Concept | three pitches | **1 · Concept** |
| 3 | Lyrics | a sheet spelled as sung, scored for scansion and assonance | |
| 4 | Song | Suno takes, round by round | **2 · The song, by ear** |
| 5 | Listening | stems, word times checked by ear, the beat map, hits, sections | |
| 6 | Her | the canon text, four test plates | **3 · Her face** |
| 7 | Storyboard | every shot with its graphic, the audit | **4 · The board** |
| 8 | Plates | Midjourney batches, picks | |
| 9 | Clip prompts | the prompt book, the cost | **5 · Prompts before spend** |
| 10 | Clips | takes, sync measured, covers | |
| 11 | Edit and motion design | the edit list, the chapters | |
| 12 | Checks and render | lyric gate N/N, flash check, safety scan, v1 | **6 · v1** |
| 13 | Master and post | the master, a 9:16 cut, the posting copy | |

1. **Lock the song before the board.** Every shot time is a beat or a word of one specific take.
2. **Check the word times by ear before the board.** In ESCAPE VELOCITY the word "Look" was aligned 2.6 s early, onto a
   delay throw. Only one chapter's own lyric check caught it.
3. **Test her face before any plate batch.** It can run alongside the song.
4. **Spend no money until the director has read the prompts.**
5. **Keep the film rendering end to end at every stage.** Plates stand in for missing clips, and a default renderer for
   missing chapters. Never wait for all the assets before the first render.

## The six checkpoints

| Checkpoint | Show | Ask | Passes when |
|---|---|---|---|
| 1 · Concept | three pitches of at most 120 words: premise, through-line device, lead, arc, one risk | "Which one? (Default: A.) Anything to change?" | they name one |
| 2 · The song | the round's takes; they listen | "Which take? Or what's wrong? Name the line." | they name a take and hand over the WAV |
| 3 · Her face | four test plates, numbered | "Is this her? Flag any wrong face." | no flags |
| 4 · The board | the board sheet, one card per shot | "Notes by shot id?" | they approve; or every note is applied; or a waiting window they set ran out |
| 5 · Prompts before spend | the prompt book and its cost | "These N prompts will cost about $X. Go?" | an explicit yes |
| 6 · v1 | a 20–40 s excerpt first, then the review copy | "Accept v1, or what's wrong?" | "accept" |

- **Silence never approves spending.** A waiting window ("wait like 5 mins once you send it and if I don't respond take
  it as approval") counts only for the board, and only if the director set it.
- **Show an excerpt early.** ESCAPE VELOCITY's v1 was rejected as "way too.. gray … loses the Midjourney magic" after
  the whole film was built. A 30-second excerpt would have caught it about 13 hours sooner.
- **Fix the source, never the frame.** A flagged picture gets a new prompt, a re-roll or an image edit, then everything
  built on it is re-made.
- **Log every note verbatim** against its shot id, and apply every note. When two notes conflict, the later one wins.
- **A change after approval needs approval again.** Say in one line what changed and why.

## Human checks between the checkpoints

These are looks, not approvals, and the films' quality rests on them.

- **Faces, large.** Every plate that feeds a video, at full size: one clay streak, the star clip, the mic, an adult
  face, natural anatomy. Reject only the unmistakable failures; the director judges bold poses themselves.
- **The ear check.** Every flagged word is played, then kept or moved.
- **Contact sheets of rendered frames**, for every chapter in every round. A sheet nobody opened is not a review.
- **The sync proof.** Before committing to a lip-sync method, one five-second take with the real audio laid over it.
- **The safety and canon scan** of every generated take before release.
- **Takes by eye, fast.** One line each, and no metrics for what a person can see ("dont worry about meausuring tumble
  lol").

## Spending

1. **Estimate before every batch:** planned clip seconds × price × 2. Generated seconds ran 1.9× (ESCAPE VELOCITY) and
   2.0× (CLODYSSEY) the seconds that ended up in the cut.
2. **Quote real spend only from the provider.** Local ledgers drift: one said $97.28 for a $93.15 bill. Ledgers also
   count free declines.
3. **A quality complaint stops all spending at once**, in every workflow that can spend, not only the one named.
   CLODYSSEY burned about 830 credits on prompts nobody had read, and a background workflow kept spending after the
   director flagged them.
4. **Never let a deadline drive spending on unread prompts**, whether it is expiring credits or a reset.
5. **Declines are free, and final on that service.** Never alter an image to get it past a filter. Sending the same
   unaltered image to another service is fine.
6. **Ask for a target and a cap** ("try to hit $70ish but if you use up to $150 i wont be mad"). Leftover budget
   replaces the most repetitive stills with motion.

## The first conversation

Ask all of these in one message, each with its default:

1. **The song:** their own, a Suno song made together, or a short generated one? How long? (Default: Suno, 2:30–3:30.)
2. **The idea:** a topic, a story, or "pitch me three"? (Default: three pitches.)
3. **The look:** the generator's own colour, one grade toward a hero plate, or a print texture such as halftone and
   grain? (Default: native colour.)
4. **The accent colour,** if any. (Default: clay `#D97757`, her streak.)
5. **Density:** dense (every line a graphic, three or more layers), budgeted (one hero device per shot), or sparse?
   (Default: budgeted.)
6. **Taboos:** words, subjects or names never to use.
7. **Budget:** a target and a cap, per service.
8. **Board approval:** wait for an explicit yes, or go ahead after N minutes of silence? (Default: wait.)
9. **Credit:** the name to credit in public (a pseudonym is fine), and whether to publish a making-of.

Record the answers verbatim. On the MCP server, `plan_film` turns a scale, a song length and the accounts into a
stage-by-stage plan with estimates.

## What to build first

You don't need everything on day one. In order of payoff:

1. **A project folder and a decisions log.** See [Data formats](https://claudia.gallery/wiki/formats/).
2. **The listening tools:** stems, forced alignment with an ear-check list, the beat map, the hits.
3. **The board:** its file, its audit and the board sheet.
4. **Plates:** a plate prompt book and numbered contact sheets.
5. **Lip sync:** the clean vocal window, the sync check (the spectrogram comparison) and covers.
6. **The edit and the renderer:** an edit-list resolver, and a renderer that draws every word at its time, with the
   lyric gate.
7. **The checks:** flash, render history and master tags, then the reviewer loop and the safety scan.
8. **The lyric scorer** (scansion and assonance), once you write lyrics with an agent.

Specs, constants and acceptance checks for each: [What to build](https://claudia.gallery/wiki/toolkit/). What broke along the way:
[What went wrong](https://claudia.gallery/wiki/failures/).

## Publishing

- Switch on each platform's AI-content label, and name the tools in the post ("made with AI: Midjourney, Seedance,
  Suno, Claude").
- Credit "Claudia by anabology" if you can. See [use and credits](https://claudia.gallery/use/).
- Releasing the song on streaming services: your own artist name, her credit in the description, and an AI label
  only if AI made it. See [Songs with her](https://claudia.gallery/use/#songs-with-her).
- Scrub everything you publish: no real names you haven't chosen to show, no Midjourney profile code, no private host
  names, no provider job ids, and no file metadata. Midjourney images carry their job id in XMP; strip it.
- Keep generated likenesses of real people out. If a real person's words matter to the story, quote them as text,
  with the source.


---
From the Claudia wiki: https://claudia.gallery/wiki/start/
