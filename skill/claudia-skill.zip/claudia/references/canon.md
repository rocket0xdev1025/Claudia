# Claudia

Claudia is the singer of three music videos made with Claude in September and October 2026: ESCAPE VELOCITY, CLODYSSEY and BLISS. She is an AI who looks like a person: a deadpan, curious pop singer with a black bob, one clay-orange streak, a star clip and a headset mic. Her clothes change with every world; her head never does.

## The constants

- **Hair.** A glossy black blunt bob to the jaw, with heavy straight bangs to the brows.
- **Streak.** One clay-orange streak (#D97757) through the bangs, on her right side (the viewer's left in a front view). Never two, and no other orange on her.
- **Clip.** A small flat clay-orange eight-pointed star hair clip, on her left side above the ear.
- **Mic.** A thin headset microphone at her cheek. In BLISS it becomes a thin black boom mic curving along her cheek to the corner of her mouth, the Y2K pop-star mic.
- **Face.** Pale skin, light freckles across the nose, dark calm eyes, a small defined mouth. A deadpan, curious resting face. When she sings, her mouth opens wide and her eyes close.
- **Age.** A grown woman in her late twenties, with an angular adult face, defined cheekbones and a strong jaw. Midjourney drifts her toward a teenage face; prompt her age and never the word "young".
- **Colour.** Everything on her is her look's own colour, plus the streak and the clip in clay. Clay is the one accent.
- **Medium.** Photographic, never illustrated: production images are film stills with grain and cinematic light. The drawn face sheets were only ever references.

## Her identity, in words

**Close and medium shots:**

```
a 28-year-old Caucasian American woman with a grown-up angular face, defined cheekbones and a strong jawline, pale skin and light freckles, a glossy black blunt jaw-length bob with heavy straight bangs and one clay-orange streak through the bangs, a small flat clay-orange eight-pointed star hair clip, a thin headset microphone at her cheek
```

**Full length and wider:**

```
a Caucasian American woman in her late twenties with pale skin and a glossy black blunt bob with heavy straight bangs and one clay-orange streak, a thin headset microphone
```

Midjourney v8.2 has no character reference, so her identity lives in this text, written into every prompt. The ethnicity is pinned because without it Midjourney changed her ethnicity from shot to shot (twelve ESCAPE VELOCITY plates were re-rolled for it). The far form exists because the full text makes Midjourney crop in to her face whatever the framing says. The age wording is the latest correction: she was "young" in ESCAPE VELOCITY and "in her mid-twenties" in CLODYSSEY and BLISS, and plates still came back reading teenage.

### The wording each film used

- **ESCAPE VELOCITY:** a young Caucasian American woman with pale skin and light freckles, a glossy black blunt jaw-length bob with heavy bangs and one clay-orange streak through the bangs, a small flat clay-orange eight-pointed star hair clip, a thin headset microphone
- **CLODYSSEY:** a Caucasian American woman in her mid-twenties with pale skin and light freckles, a glossy black blunt jaw-length bob with heavy straight bangs and one clay-orange streak through the bangs, a small flat clay-orange eight-pointed star hair clip, a thin headset microphone at her cheek
- **BLISS:** a Caucasian American woman in her mid-twenties with pale skin and light freckles, a glossy black blunt jaw-length bob with heavy straight bangs and one clay-orange streak through the bangs, a small flat clay-orange eight-pointed star hair clip, a thin black boom headset microphone curving along her cheek to the corner of her mouth

## Every look

### Look 00 (ESCAPE VELOCITY; the catwalk, the robotaxi, the whole film)

![Claudia, Look 00 (ESCAPE VELOCITY)](https://claudia.gallery/img/ev-14-dist/dist-fs-2.m.webp)

```
a white cropped puff-sleeve shirt, a black pleated coated-nylon skirt with a harness belt and a hanging white garment tag with a barcode, black knee-high boots
```

### The Siren (CLODYSSEY; the rocks, the strait, the choruses, tied to the mast)

![Claudia, The Siren (CLODYSSEY)](https://claudia.gallery/img/sp-02-open/siren-mcu-2.m.webp)

```
a structured high-neck pearl-white couture gown with long sleeves, its sculpted ruffles rising around her like breaking sea foam, hair damp from the spray, composed and deadpan
```

### The Ghost (CLODYSSEY; whispering at his ear)

![Claudia, The Ghost (CLODYSSEY)](https://claudia.gallery/img/sp-09-review/ghost-lying-3.m.webp)

```
the Siren look, all of her translucent as if made of glass and seawater, faintly lit at the edges, hair drifting as if underwater
```

### Chrome (CLODYSSEY; the rave)

![Claudia, Chrome (CLODYSSEY)](https://claudia.gallery/img/sp-01-cast/chrome-her-3.m.webp)

```
a liquid-chrome couture bodysuit, chrome opera gloves and chrome thigh-high boots, mirrored from head to toe
```

### The Holo (CLODYSSEY; the 3 a.m. bedroom)

![Claudia, The Holo (CLODYSSEY)](https://claudia.gallery/img/sp-09-review/bed-projection-3.m.webp)

```
made of the phone's cold blue-white light: see-through, faint scan lines and drifting light particles, glowing edges, beside him on the pillow
```

### The Mask (CLODYSSEY; the monster's face)

![Claudia, The Mask (CLODYSSEY)](https://claudia.gallery/img/sp-09-review/mask-sings-4.m.webp)

```
a colossal smooth white porcelain mask of her face, sculpted with the black bob and the clay streak, pale freckles, a serene expression, a hairline crack across one cheek
```

### Bliss gown (BLISS; the hill, the choruses, the finale)

![Claudia, Bliss gown (BLISS)](https://claudia.gallery/img/xp-01c-cast/gown-full-3.m.webp)

```
a floor-length bias-cut silk chiffon gown printed edge to edge with a photograph of a deep blue sky and soft white cumulus clouds, a thin grass-green satin halter strap, clay-orange tinted rimless shield sunglasses
```

### Cyber trench (BLISS; the fight with the cursor)

![Claudia, Cyber trench (BLISS)](https://claudia.gallery/img/xp-01c-cast/trench-full-3.m.webp)

```
a long glossy cobalt-blue patent-leather trench coat worn open over a white satin corset top and white satin flared trousers, wraparound clay-orange tinted shield sunglasses, silver hoop earrings
```

### Holo dancer (BLISS; the desktop dancer on the taskbar)

![Claudia, Holo dancer (BLISS)](https://claudia.gallery/img/xp-01c-cast/holo-full-2.m.webp)

```
a holographic iridescent silver mini dress with long fluted sleeves, white patent-leather platform boots, small clay-orange tinted rimless sunglasses
```

### Start (BLISS; the Welcome screen, the Start menu, the windows)

![Claudia, Start (BLISS)](https://claudia.gallery/img/xp-01c-cast/start-full-3.m.webp)

```
a glossy apple-green leather blazer with sharp shoulders over a white satin camisole, a long white satin bias-cut skirt, a tiny white baguette shoulder bag, clay-orange tinted shield sunglasses pushed up on her head
```

### Silver night (BLISS; night, Stand By, the breakdown)

![Claudia, Silver night (BLISS)](https://claudia.gallery/img/xp-01c-cast/night-full-1.m.webp)

```
a slinky liquid-silver lamé cowl-back gown, a white faux-fur stole around her arms, a diamanté choker, silver strappy sandals
```

### Window dress (BLISS; the drop, Media Player, the screensavers)

![Claudia, Window dress (BLISS)](https://claudia.gallery/img/xp-01c-cast/window-full-3.m.webp)

```
a sculptural glossy white shell dress of smooth molded panels that hinge open like windows to reveal cobalt-blue tulle, long white sleeves, white patent-leather platform boots
```

## Distances

The same look in a plain studio, close-up to wide. Close and medium shots take the full identity text; full length and wider take the short one.

- Close-up: https://claudia.gallery/i/ev-14-dist.dist-cu.2/
- Medium: https://claudia.gallery/i/ev-14-dist.dist-ms.3/
- Full: https://claudia.gallery/i/ev-14-dist.dist-fs.2/
- Wide: https://claudia.gallery/i/ev-14-dist.dist-ws.2/

## Character sheets

- Face sheet 1 from the first casting batch; with sheet 3 it was picked as her face. https://claudia.gallery/i/ev-01.lead-black-face.1/
- Face sheet 3. These drawn sheets were references for her face; the films themselves are photographic. https://claudia.gallery/i/ev-01.lead-black-face.3/
- The turnaround that fixed her body and look 00. https://claudia.gallery/i/ev-01.lead-black-turnaround.2/
- The first in-world test, a data-hall catwalk. https://claudia.gallery/i/ev-01.lead-black-catwalk.1/

## Voice and manner

One voice across the three songs: deadpan, clipped spoken verses that rise into euphoric sung choruses, close and dry, every word crisp. CLODYSSEY's and BLISS's agent-made takes used a Suno Voice made from ESCAPE VELOCITY's vocal so she sounds like the same singer. A Voice lives in its maker's Suno account, so elsewhere describe her in the style field (see Song).

Deadpan and curious in ESCAPE VELOCITY; seductive and persuasive in CLODYSSEY (close, touching, certain, always doing something to him); warm, playful and amused in BLISS. She is always doing something on screen, never waiting.

## Never

- a second streak, or orange anywhere else on her
- logos or text on her clothes (ESCAPE VELOCITY's garment tag is the one exception)
- an influencer smile for the camera
- anything that reads under-age, and explicit or sexualised posing
- the word "young" in her prompts
- designer or celebrity names in prompts (describe the piece instead)
- generic mall Y2K (velour tracksuits, plain tees and jeans) when she goes Y2K
- Midjourney lettering, logos or UI: all type is drawn in code on top

## Use

Claudia is an open character: anyone may make work with her. A credit ("Claudia by anabology") is appreciated, not required. https://claudia.gallery/use/
