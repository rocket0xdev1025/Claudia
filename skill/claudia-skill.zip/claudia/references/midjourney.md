# Plates in Midjourney

How every still of Claudia and her worlds was made in Midjourney v8.2, prompt by prompt, and how the stills were picked.


Midjourney was the art department for all three films: 487 prompts, 1,595 images, about 330 plates. A plate is the still
a shot is built on, either as a 2.5D image animated in code or as the first frame of a Seedance clip. Every prompt and
image is in this gallery; open any image to see the prompt that made it.

## Settings

- **Model:** Midjourney v8.2 with `--raw --hd`.
- **Aspect:** `--ar 16:9` for plates; `--ar 2:3` for her full length, `--ar 4:5` for inserts, `--ar 1:1` for square tiles.
- **Profile:** every film ran with the director's personal Midjourney profile, which carries their taste. It is
  personal and not shareable: use your own profile, or none, and expect a different finish.
- **No style references, no character references.** Her identity is prompt text ([Consistency](https://claudia.gallery/wiki/consistency/)).
  The only image prompts were the Mask's (her face sheet, `--iw 0.4` to `0.75`) and a few early face tests.
- **Length:** keep prompts under about 800 characters. Past that, Midjourney rewrites the prompt into its own words.

## The anatomy of a prompt

Every plate prompt is one concrete shot from the storyboard, in this order:

1. **Framing first:** extreme close-up, close-up, medium close-up, medium, full-length, wide, extreme wide, aerial.
2. **Her identity text** (full for close and medium shots, short for full length and wider).
3. **Her wardrobe** for that world.
4. **What she is doing and where**, including where she sits in the frame.
5. **Empty space for type**, when the shot carries words: "the upper third empty fog", "the left third empty white".
6. **The film's style family:** light, palette, grain, finish.
7. **"no text, no letters, no logos"**, always last. All type is drawn in code on top.

A close-up from CLODYSSEY, as it ran:

```prompt
medium close-up of a Caucasian American woman in her mid-twenties with pale skin and light freckles, a glossy black blunt jaw-length bob with heavy straight bangs and one clay-orange streak through the bangs, a small flat clay-orange eight-pointed star hair clip, a thin headset microphone at her cheek, wearing a structured high-neck pearl-white couture gown with long sleeves, its sculpted ruffles rising around her like breaking sea foam, hair damp from the spray, composed and deadpan, sitting on a black wet rock, turning her face to the lens, sea spray behind her, empty dark sea on the left, night, moonlight on a black-teal sea, silver spray, cinematic 35mm film still, anamorphic, fine grain, no text, no letters, no logos
```

[![The Siren on her rock (sp-02-open / siren-mcu #2). The director picked it, and it is a plate in the film.](https://claudia.gallery/img/sp-02-open/siren-mcu-2.m.webp)](https://claudia.gallery/i/sp-02-open.siren-mcu.2/)

## Style families

Each film keeps one family of style words at the end of every prompt, which is what keeps 100+ plates in one world.

**ESCAPE VELOCITY:** night, cold and monochrome, with one warm note.

```prompt
blue-black #0f1216 and steel blue, one small red lamp as the only warm note, fine silver-gelatin grain, cinematic 35mm film still, no text, no letters, no logos
```

**CLODYSSEY:** a light state per chapter, from night to morning, as the ship sails.

| Chapter | Light |
|---|---|
| Night | night, moonlight on a black-teal sea, silver spray, cinematic 35mm film still, anamorphic, fine grain |
| Dusk | dusk, low gold light on a glassy sea, violet sky |
| Twilight | deep blue twilight, the last gold on the horizon, glassy sea |
| The break | grey first light before sunrise, heavy spray |
| Final chorus | sunrise, warm gold light and long shadows, spray lit gold |
| Bedroom | a dark bedroom at 3am lit only by a phone screen, blue-white glow on the face |
| Rave | a San Francisco warehouse rave, fog, white strobe, chrome reflections, deep black, flash photography |
| Inserts | macro product photograph, hard rim light, razor-thin focus |

**BLISS:** an opener instead of a closer. Every prompt of her starts the same way, and the clothes do the talking.

```prompt
Y2K high fashion editorial, a 2001 couture magazine story: close-up of a Caucasian American woman in her mid-twenties with pale skin and light freckles, a glossy black blunt jaw-length bob with heavy straight bangs and one clay-orange streak through the bangs, a small flat clay-orange eight-pointed star hair clip, a thin black boom headset microphone curving along her cheek to the corner of her mouth, clay-orange tinted rimless shield sunglasses pushed into her hair, the sky-printed silk chiffon of her gown at the shoulder, a knowing half-smile, bright midday sun, a deep blue sky behind her, sharp focus, fine film grain, no text, no letters, no logos
```

BLISS also kept brand words out of every prompt ("Windows", "Microsoft" and "XP" summon logos and garbled UI) and
described the hill and the light instead: "a smooth rolling bright-green grassy hill with soft curves, the grass short and velvety".

## Wardrobe words

The director's note on BLISS's first two wardrobe passes: "idk i dont love these - id say more say y2k high fashion - like
use those words high fashion adn make it not as generic y2k person". The fix was literal: the words "high fashion" and
a statement piece per look, described as a garment rather than a brand. Never name a designer or a celebrity; describe
the cut, the fabric and the colour.

## Green screen

Plates that will be cut out (the desktop dancers, the cursor fight) put her on a flat chroma green:

```prompt
Y2K high fashion editorial, a 2001 couture magazine story: full-length shot, head to toe with the feet in frame, of a young Caucasian American woman with pale skin and a glossy black blunt bob with heavy straight bangs and one clay-orange streak, a thin black headset microphone, wearing a sculptural glossy white shell dress whose molded panels open like windows onto cobalt-blue, white patent platform boots, dancing mid-move with both arms raised, centered on a flat chroma-key green studio backdrop, even flat light, no shadows on the backdrop, no text, no letters, no logos
```

(This is BLISS's prompt as it ran. Today, swap "a young" for "in her late twenties"; see [Consistency](https://claudia.gallery/wiki/consistency/).)

## Picking

- **Batches of four.** Each job returns four images. Contact sheets with numbered candidates make picking fast.
- **One image per shot.** Never reuse a plate for two shots, and never start two clips from the same frame. The
  three images that weren't picked are a free pool of variants for neighbouring shots.
- **Pick for composition, story and the look.** Reject unmistakable failures: a doubled face, a third arm, a second
  streak, a teenage face. Keep bold poses.
- **Look at the faces large.** The director reviewed every plate on the storyboard, and in CLODYSSEY left 70 notes
  ("s018 color is PERFECT", "kinda bodyslop", "a virtual ghost"). Those notes are in the gallery: images marked
  *director's pick* or *rejected*.
- **Throughput.** About a minute per job; about 45–50 minutes for 50 jobs.

## Midjourney Animate

BLISS used Midjourney Animate for volume: one click per image, no prompt, a moving picture for 31 windows on the XP
desktop and three full-frame shots. The director's rule: Animate is for "any gens that need volume over precision, where
seedance reigns on precision." Her face and body, when they had to be right, went to Seedance.

## Composition in Midjourney, type in code

Midjourney finds compositions and textures. Its lettering is garbled and its UI is wrong, so nothing typographic is ever
kept: every word, title bar, split-flap and label in the films is drawn in code on top of the plate, in real fonts.
For posters and covers, the same split: let Midjourney compose with the film's stills as image prompts, then rebuild the
layout in code from the film's own plates and real type.

## The real thing where it counts

BLISS's first wallpapers were Midjourney hills. The film uses the real Bliss photograph instead, and the real XP sound
files, because the nostalgia lives in the exact picture and the exact sounds. Midjourney is for everything that doesn't
already exist.

## Every prompt

The complete prompt records, batch by batch, with what became of each image:

- [ESCAPE VELOCITY: 188 prompts](https://claudia.gallery/record/escape-velocity/prompts-midjourney/)
- [CLODYSSEY: 161 prompts, and the director's 70 notes](https://claudia.gallery/record/clodyssey/prompts-midjourney/)
- [BLISS: 138 prompts, and the 38 Animate requests](https://claudia.gallery/record/bliss/prompts-midjourney/)


---
From the Claudia wiki: https://claudia.gallery/wiki/midjourney/
