# The whole pipeline

How one director and Claude made three music videos in about 80 hours of wall-clock time, stage by stage, with the numbers.


Each film was made by one director, anabology, making every taste call in a few dozen short notes, and Claude (Opus 5.5
in Claude Code) as the production team: research, lyrics, storyboard, every prompt, every script, the edit and every
frame of motion design. Many of the stages ran as multi-agent workflows: several agents working in parallel, judged
and merged.

## The stages

Starting a film of your own? [Start here](https://claudia.gallery/wiki/start/) has the checkpoints, the accounts and the spending rules;
[What to build](https://claudia.gallery/wiki/toolkit/) specifies the tools.


1. **Brief.** The director's ask, word for word, then each decision with its date. Taboos and standing rules go in the
   brief and into every agent's prompt.
2. **Research.** Agents build banks of live memes and events, each fact checked by a separate verifier agent. BLISS also
   researched the XP sound files (downloaded and pitch-analysed), the old desktop-dancer programs and how to steer Suno.
3. **Lyrics.** Several writers from different angles (density, tension, hook, story), judges, a merge, a critic pass,
   then the scansion scorer. See [Song](https://claudia.gallery/wiki/song/).
4. **The song.** Suno takes, round after round, picked by ear; the director often made the final take themselves.
5. **Listening.** Stems, a beat map, every word's time, a list of hits. Everything after sits on that grid.
6. **Her.** The canon text and the looks for this world, tested on a few plates before any batch. See
   [Consistency](https://claudia.gallery/wiki/consistency/).
7. **Storyboard.** Three director agents board the song independently (in ESCAPE VELOCITY: fashion film, meme density,
   narrative), judges score them, a head director merges the best into one board. Every shot carries its lyric, its type
   device, its plate prompt, its camera on the song's hits and what its graphic explains. The director reviews a PDF of
   the board; CLODYSSEY got 70 notes shot by shot.
8. **Plates.** Midjourney batches, contact sheets, picks, one image per shot. See [Midjourney](https://claudia.gallery/wiki/midjourney/).
9. **Moving shots.** The prompt book, written by hand in one context and read before spending, then Seedance with lip
   sync measured. See [Seedance](https://claudia.gallery/wiki/seedance/).
10. **The edit.** An edit list that resolves singing takes and their covers moment by moment. Stills stand in until clips
    exist, so the film renders end to end at every stage.
11. **Chapters.** One animator agent per chapter, an art-director agent reviewing real rendered frames, a fixer; in
    BLISS's second round, review → fix → verify → finish, with notes on the seams between chapters. See [Motion](https://claudia.gallery/wiki/motion/).
12. **Checks and render.** The lyric gate, contact sheets, the flash test, then a CRF 16 master.

## What the director did

Taste, at checkpoints, in very few words. ESCAPE VELOCITY took about 50 notes, CLODYSSEY 68, BLISS 21. A few that
changed whole films:

- "way too.. gray … loses the Midjourney magic" (ESCAPE VELOCITY's colour)
- "s018 color is PERFECT" (CLODYSSEY's grade)
- "EVERY prompt needs to have litearlly timestamps, extremely detailed motion descriptions / blocking descriptions"
- "Can you use actual bliss as the bg or too late?" (BLISS's wallpaper)
- "idk i dont love these - id say more say y2k high fashion" (BLISS's wardrobe)

More of them, in context, in each film's making-of: [ESCAPE VELOCITY](https://claudia.gallery/record/escape-velocity/readme/) ·
[CLODYSSEY](https://claudia.gallery/record/clodyssey/readme/) · [BLISS](https://claudia.gallery/record/bliss/readme/).

## Lessons from running it

- **One hand writes the prompts that cost money.** CLODYSSEY's first round of video prompts was written by planner agents
  and spent about 830 credits on lifeless takes before anyone read them. Since then, every paid prompt is written in one
  context and read before anything is submitted.
- **Spend only after reading.** A background workflow with its own spending stage kept spending after the director had
  flagged the prompts. Stop generator workflows the moment quality is in question.
- **Empty is not a pass.** When agents ran out of usage mid-run, chapter reviews came back empty and the scripts read
  "empty" as "nothing to fix". A review that returns nothing is a failed review, in code; check that every agent
  actually finished.
- **Long runs need their permissions in advance.** One write outside the allowed folders stalled a whole run on a
  single approval prompt.
- **Watch the queues.** Every clip import queued a 16-minute matte job; after 80 re-makes the GPU queue was about 20 hours
  deep. Cancel superseded jobs so the shots that matter go first.
- **Parallelism has a ceiling.** On a 4-CPU machine a workflow ran two agents at a time; splitting chapters into more
  workflows helped less than expected (1.1–1.5× measured, not 3×).
- **Keep run records.** Long workflows get interrupted; resume them by run id and let finished agents replay from cache.

## The numbers

| | ESCAPE VELOCITY | CLODYSSEY | BLISS |
|---|---|---|---|
| Length | 5:06 | 3:11 | 3:01 |
| Shots | 141 | 94 | 44 |
| Midjourney | 188 prompts · 636 images | 161 prompts · 644 images | 138 prompts · 315 images |
| Seedance 2.5 | 47 clips + 30 continuations | 101 clips · 189 takes | 50 clips |
| Wall-clock | about 19 h | about 41 h | about 19 h |
| Director's notes | about 50 | 68 | 21 |
| Claude tokens | 1.4 B | 2.37 B | 2.25 B |
| Claude at API list prices | ≈ $626 | ≈ $1,007 | ≈ $714 |

The Claude figures are what the same work would cost at API list prices; the films were made on a subscription. About
96–98% of all tokens were prompt-cache re-reads of long contexts.

## The full records

Each film's making-of: the story and the numbers, and every prompt for every tool.

- [ESCAPE VELOCITY](https://claudia.gallery/record/escape-velocity/)
- [CLODYSSEY](https://claudia.gallery/record/clodyssey/)
- [BLISS](https://claudia.gallery/record/bliss/)


---
From the Claudia wiki: https://claudia.gallery/wiki/pipeline/
