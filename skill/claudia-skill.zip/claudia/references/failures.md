# What went wrong

Every failure that cost the films time or money, as what you see, why it happened, and the rule that came out of it.


Each row cost at least one round-trip, and some cost hours or hundreds of credits. Each one left a rule behind. "Another
project" is a production made with the same tools between the films.

## Brief and taste

| What you see | Why | The rule now |
|---|---|---|
| v1 rejected for its look: "way too.. gray", "color grading looked insane", "dont love the dot grid" | the look was assumed, not asked | Ask up front: native colour, one grade, or a print texture. Record the answer. |
| Plates "feel like a stock photo" | generic subjects: crowds, elderly or patient portraits, hands holding props | Change the idea entirely, not the seed, or make the shot pure motion design. |
| A sequel's song feels like a copy | it reused the last song's device, a countdown | A sequel never reuses the previous film's device. |
| Viewers read the lead as a teenager | age words and schoolgirl-coded wardrobe | Write an explicit adult age, use editorial wardrobe, and never write "young". |
| A taboo word turns up in a label or a file name | the taboos lived only in the brief | Put taboos in the project file and in every agent's prompt. The audit checks the board; grep code and file names before release. |
| "off pace and off vibe with the song" | the busiest picture sat on the quietest music | Measure picture motion against stem energy per section. |
| Agent-written style rules pulled work away from what the director liked | rules without a verdict behind them | Keep exemplars and verbatim verdicts. No style rule without the director's yes. |

## The song

| What you see | Why | The rule now |
|---|---|---|
| The song came out twice as long as planned (2:19 → 5:06) | Suno gives each spoken line its own two-bar slot | Plan two bars per spoken line, and write 10–13 syllables with the stresses on the beat. |
| Verses went choppy after optimising a score | a metric that rewards short clauses on the pulse | Use flow for verses and groove for chants, calibrated to the director's ear. |
| A name mispronounced | Suno's reading | Respell it in the Suno field only; the screen keeps the real spelling. |
| Numbers and acronyms sung wrong | written as digits | Spell them as sung ("A G I") and show "AGI" on screen. |
| The lyric rushed or truncated, silently | the lyrics field ran over about 3,000 characters | Aim for 1,800–2,400 characters for about 2:20. |
| The chosen take can't be fetched | the download is a native browser download, and the CDN wants signed URLs | The person downloads it; that download is also the licensing step. |
| "A voice already exists for this song" | Suno allows one Voice per source song | Make one combined Voice, spoken and sung. |
| A patched export drifted the song by up to 0.7 s | an editor export with BPM lock on | Export with the lock off, diff the spectrograms, and time-map the edit instead of re-cutting. |
| A new take changed the song's shape | takes differ in structure, not only in timing | Re-time the board from word anchors, and restructure by hand where the shape changed. |

## Listening

| What you see | Why | The rule now |
|---|---|---|
| Cuts drift off the beat later in the song | a fixed BPM on an accelerating take (131.5 → 133.9) | A variable beat map, never one BPM. |
| One chapter's lyric check failed on a word 2.6 s early | a delay throw aligned as the word | Ear-check gaps over 1 s and very low confidence before the board. |
| Bars start on beat 2 | claps on 2 and 4 won the downbeat vote | Add a chord-change vote, check by events, and keep an override. |
| The loudest moment gets no camera impact | the detector missed a hit that grew out of a loud chorus | Keep a manual add and drop list of hits. |
| Snare and hat lists full of kick clicks | a broadband kick fires in every band | Drop onsets within 45 ms of a kick. |
| Sung lines and shouts missing from the alignment | the aligner is weak on singing; the transcriber missed shouts | Merge the two aligners by confidence. Copy a shout from the earlier chorus plus the bar offset, and mark each word's source. |

## Her and the plates

| What you see | Why | The rule now |
|---|---|---|
| Her ethnicity drifts; 12 plates flagged | the prompt didn't pin it | The canon text pins ethnicity, age and skin in every prompt. Test four plates before any batch. |
| Identity edits drift from the look, and refuse seated poses | an image model "replacing only the woman" | Identity is prompt text only. |
| A close-up-sized head on a distant figure | face image references: a whole sheet imports its layout, a single face over-conditions | No face references for identity. |
| "Version 8.2 doesn't support --oref" | that parameter doesn't exist on that version | Don't use it. |
| Full-length prompts come back as close-ups | the long face canon pulls the frame in | Camera first, plus the short far form of the identity. |
| A feature asked for as an adjective goes missing | it wasn't the subject of the sentence | Make the feature the subject ("the hide studded with dozens of large glossy eyes"). |
| The crew are copies of the male lead | one description for a whole cast | Describe each extra (age, build, hair) and add an explicit negative. |
| A sheer gown read as plastic wrap and nude | "sheer … bare shoulders, bare feet" | A structured, high-neck, long-sleeved look, "composed and deadpan". |
| A stranger in an over-the-shoulder shot | the shoulder had no canon | Over-the-shoulder shots carry the canon too. |
| The robotaxi came back as an old sedan | the object's form wasn't named | Name it: "a small white compact electric SUV robotaxi with a tall spinning lidar dome". |
| The same image on about six shots | stand-in aliases left in the board | One image per shot; use the unpicked candidates as a variety pool. |
| "Two heads next to each other" ("bodyslop") | a ghost and a person composed in one prompt | Describe the ghost as made of the scene's light, or compose two assets. Make groups with an edit model. |
| A fix painted by hand in code | fixing the frame instead of the source | Bake it into the prompt or use an image-edit model. Never paint pixels. |
| The edit model invented a six-pointed star | edit models invent details | Re-check the canon after every edit, and name the exact form ("exactly eight points"). |
| Edited plates rendered with their old depth | prep wasn't re-run | Re-run depth and boxes after every plate edit. |
| Images matched to the wrong prompts | jobs identified by position, and Midjourney rewrites long prompts | Identify each job by its own prompt text. |
| Lost picks | parallel runs racing on one state file | Use a locked read-modify-write. |

## Clips and lip sync

| What you see | Why | The rule now |
|---|---|---|
| Lifeless takes, about 830 credits burned | agent-written prompts: poses, not drama, and nobody read them | One writer writes every prompt in one context, with the story beat, blocking, and timestamped action and reaction. The director reads the book before any spend. |
| Sung takes re-sing the line instead of copying it | long timestamped screenplays on sung windows | Use the short sung form for sung windows, and screenplays for motion. |
| One window barely syncs whatever the prompt | a microphone at her mouth on the plate | Sung plates show the whole mouth, with nothing in front of it. |
| QA kept weak takes | takes were checked against their own weak prompts | Check takes against the story and the board. |
| Two clips start on the same frame ("jarring") | the same plate as the start image | Use a sibling candidate, or the previous clip's last frame. |
| Lip-sync models "still not exact" | the failure was the input, not the model | Measure, cut, cover; otherwise cut away. No lip-sync models. |
| A take diverges inside a word | the prompt quoted fewer words than the window held | Quote exactly the window's words, and start windows in word gaps. |
| Lips a fraction early or late in the edit | each take has its own lag, up to ±1 s | Map clip time and song time through each take's measured lag. |
| A window cut a word ("…could. Your P") | the window ended mid-word | Start and end windows in word gaps. |
| Motion clips "diverge" in the sync check | the mix isn't copied (NCC about 0.08) | Expected: play motion clips at lag 0. |
| Grey proxy shapes in a take | a 3D previz video reference leaked into the output | "take only the camera move from it", or drop the reference. |
| Drift on long sung clips | lip sync degrades over length | Sung windows of 4–8 s, never longer. |
| Head counts change, actions reverse, garbled text | under-specified prompts | "exactly four …", name the end state, one dominant camera move, "No text, letters or logos". |
| "Upscaled" footage looks waxy and shimmers | learned upscalers | Keep Lanczos, and generate hero shots at 1080p instead. |
| 32 of 59 clips came back near grey | references pre-graded to monochrome | Send references in colour; any look goes on in post. |
| A sung clip ignores its audio | a first frame sent with the audio reference | On OpenRouter, use reference mode for sung clips and covers, never `frame_images`. |

## Filters and providers

| What you see | Why | The rule now |
|---|---|---|
| Close-up references declined | the provider's face filter | Free, and final for that image on that service. Send the same unaltered image elsewhere, or keep the 2.5D plate. |
| A retry ladder (stronger grade → posterised grade) got takes through, baked banding into them, and was blocked by the harness | altering a reference to pass a safety filter | Never alter an image to pass a filter. A blocked action is a stop, not a puzzle. |
| Jobs fail with no reason, credits back seconds later | a silent input filter misreading innocent wording ("a plug pushed deep into each ear" for foam earplugs) | Reword plainly and keep the beat: plain rewording fixed five of six at once. |
| "output audio may be related to copyright restrictions" | the provider's audio filter | Retry once with a re-cut window, then try the other provider. |
| A filter that passed faces two days ago now declines them | providers change | Keep a second provider configured. |
| The agent's context floods during uploads | presigned-upload replies of about 3.5k characters per file | Upload by URL. |

## Spend

| What you see | Why | The rule now |
|---|---|---|
| Every submit returns 403 while the account has credit | the API key has its own spend limit | Set the key's limit above the project cap. |
| "Remaining budget" figures are wrong | the local ledger isn't the bill, and it counted free declines | Quote spend only from the provider. |
| Hundreds of credits spent in minutes on unread prompts | a credit-reset deadline drove the spending | Never let a deadline drive spend. |
| A background workflow could still spend after a quality flag | not every spender was stopped | Stop every workflow that can spend: search each for its generate calls. |
| Credits vanished at renewal | subscription credits don't roll over, and top-ups expire | Plan spend inside the period. |

## Colour and look

| What you see | Why | The rule now |
|---|---|---|
| v1 "way too gray … loses the Midjourney magic" | a mono print pass, and chapters desaturating the footage | Colour halftone or native colour; never desaturate the footage. |
| "color grading looked insane"; blue graphics "clash" | a graded look, and a blue accent over blue footage | Native colour; pick the accent against the footage's hue; draw with semantic colour tokens. |
| Flicker in a graded clip | per-frame grading | One LUT per clip, computed from 16 sampled frames. |
| The master looks washed out ("v blown out") | an untagged or BT.601 stream | Convert to BT.709 and tag it; verify with ffprobe. |

## Motion design and the renderer

| What you see | Why | The rule now |
|---|---|---|
| A crop cut her head off after a re-take | code tuned to the old take | Re-frame every shot whose take changed. |
| The previous frame's overlay "sticks" in dense frames | a GPU-backed 2D canvas under software GL | Software-backed canvases, and the history check in QA. It took about two hours of bisecting to find. |
| Frames differ depending on what rendered before | a WebGL canvas drawn into a 2D canvas switches it to GPU rasterisation | Read 2.5D pixels back through the CPU. |
| 0.5–1.1 s a frame on 2.5D shots | the 64-step parallax shader | Depth slices or multiplanes. |
| Tags never finish typing on short shots | the default typing speed | Type at 16–40 characters a second, and finish 6 frames before the cut. |
| A lyric word half hidden on its first frame ("You dor't") | occlusion on the entering row | Tuck an edge only, and switch occlusion off for the entering row. |
| Five accent-coloured elements in one frame | the accent used for every highlight | The accent goes on at most two elements. |
| A snap reads early | keyed 70 ms before its kick | Key moves on hit times from the hits file. |
| Two on-screen numbers disagree ("x380" against "135 RUNNING") | two devices driven separately | Drive both from one value. |
| Shake in a drumless intro | a move that answers no sound | Moves answer audible sounds. Stillness where the song breathes. |
| The same helpers written 8–10 times, slightly differently | chapters couldn't share code | One shared device library. Chapters write only what is unique. |
| The default renderer drew only lyrics | the board's graphics were stored as prose | Structured fields in the board: type, devices, treatment, transition. |
| A lyric time patched in chapter code | fixing the time instead of the alignment | Fix the timed words and re-export. |
| A chapter replaced the default renderer and lost lyrics | the chapter must draw every token itself | Run the lyric gate per chapter, and mark custom-drawn tokens. |
| Fonts that can't be shipped | AGPL, GPL, EULA or unlicensed fonts | Ship OFL fonts only, with their licence texts. |
| A depth model that forbids commercial use | Depth Anything V2 Large is CC-BY-NC | Use Depth Anything V2 Small, which is Apache-2.0. |
| A singing mouth held where the take isn't synced | the edit fell back to a plate | Crops, inserts or depth moves on those words. |

## Review

| What you see | Why | The rule now |
|---|---|---|
| Runs "completed" with no review at all | a usage limit made reviewers return nothing, and the script read that as "no fixes" | A null review is an explicit failure, in code. Carry open fixes forward. |
| Reviewers scored 6–7.5 a cut the director called "perfect" | a stricter bar than the director's | Ship on "no blocking fix left". Calibrate on the director's verdicts. At most two rounds. |
| A reviewer re-ran checks until its time ran out and wrote nothing | it wasn't told what was authoritative | Bound reviewers by output: "write the short version first". |
| The scan flagged an intended prop | a generic "modern object" rule | Whitelist intended anachronisms by name. |
| A strobe counted twice | the flash check paired every transition | Count opposing pairs. |
| Twelve blocks found in 96 "final" takes | generated people; filters let outputs through | A safety and canon scan of every take before release. |
| First-draft chapters scored 5–6.5: faces printing blank, type over faces, repeated devices | animators with nobody reviewing real renders | A reviewer renders, looks, and writes concrete fixes. |

## Render and running agents

| What you see | Why | The rule now |
|---|---|---|
| Nobody knew the encode had finished | it ran as a detached job | Tracked background jobs with a status. |
| Swap and the root disk filled up | six agents rendering at once, with frames in /tmp | One rendering workflow at a time, scratch on the big disk, and check free memory and disk first. |
| Disk full after a render | about 9.6 GB of frames per cut | Delete the frames once ffprobe has verified the outputs. |
| Commands ran against the wrong project | an export inside a backgrounded shell chain | Name the project on every command. |
| A merge restarted three times (about 1.5 h) | an interrupt kills every running workflow | Short phases, run ids saved, resume by run id. |
| One serial chapter workflow would have taken about 12 h | serial agents | Three parallel workflows (about 4 h). |
| A ~20-hour background queue, new takes stuck behind superseded ones | post-processing auto-queued on every import | Queue only takes the edit uses, in priority order. Cancel superseded jobs. |
| A GPU box at 100% CPU, every job 3–5× slower | two dozen waiters polling every 3 s | One shared listing every 45 s for all waiters. |
| Duplicate jobs after a restart | killing a waiter left its child behind, and the re-run resubmitted | Record job ids beside their inputs, adopt queued jobs, and kill orphans by id. |
| Every new agent session fails at start | an agent CLI auto-updated mid-run | Pin versions for long jobs. Check the job's error before assuming there is no work. |
| A worker probed for 75 minutes and delivered nothing | no bound on the first deliverable | A first complete draft within about 10 commands, with a mandatory handoff. |
| Shared-file bugs fixed differently in parallel chapters | workers patching shared code | Workers report shared bugs; the operator fixes them once. |

## Publishing

| What you see | Why | The rule now |
|---|---|---|
| Identifying details in a making-of: names, profile codes, hosts, job ids | raw production notes | Scrub rules, a grep pass, and two fresh-eyes reads. |
| A song file carries the generator's song id in its tags | file metadata | Strip metadata from everything you publish. Midjourney images carry their job id in XMP. |
| Real-person likeness risk | generated portraits of real people | Keep generated likenesses of real people out; quote their words as text, with the source. CLODYSSEY's labelled AI IMAGE post cards are left out of this site. |
| A master posted without the AI disclosure | platform toggles missed | Set each platform's AI-content label, and name the tools. |


---
From the Claudia wiki: https://claudia.gallery/wiki/failures/
