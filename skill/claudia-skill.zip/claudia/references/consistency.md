# Keeping her herself

How Claudia stayed one person across 1,562 Midjourney images and about 200 video clips, and the rules that came out of it.


Three films, three worlds, a dozen outfits, and she still reads as one person. None of it used a character
reference, a trained model or a face swap. Her identity is a paragraph of text, written into every prompt, plus a
handful of habits for checking what comes back.

## The short version

1. **Write her identity into every prompt, in the same words.** Midjourney v8.2 has no character reference, and it
   doesn't need one if the text never changes. Copy the canon text below; don't paraphrase it.
2. **Use two lengths.** The full text for close and medium shots, a short one for full length and wider. With the
   full text, Midjourney crops in to her face whatever the framing says.
3. **Pin her ethnicity and her age.** Without the ethnicity, Midjourney changed it from shot to shot. Without a
   stated age (late twenties, an angular adult face), it drifts her toward a teenager. Never write "young".
4. **No face images as references** for her, except for things that are not her body: a porcelain mask of her face.
5. **The head never changes; the clothes always can.** Hair, streak, clip, mic and face are the constants. Each world
   gets its own wardrobe.
6. **Fix the source, not the frame.** Re-roll or correct a plate with an image-edit model, then re-make anything made
   from it. Nothing is painted by hand.
7. **Check every plate before it feeds a video:** one clay streak, the star clip, the mic, an adult face, natural
   anatomy, no text.
8. **In motion, the first frame carries her.** Seedance keeps her identity when her Midjourney plate is the first frame
   and the prompt says what must stay.

## The canon text

Close and medium shots:

```prompt
a 28-year-old Caucasian American woman with a grown-up angular face, defined cheekbones and a strong jawline, pale skin and light freckles, a glossy black blunt jaw-length bob with heavy straight bangs and one clay-orange streak through the bangs, a small flat clay-orange eight-pointed star hair clip, a thin headset microphone at her cheek
```

Full length and wider:

```prompt
a Caucasian American woman in her late twenties with pale skin and a glossy black blunt bob with heavy straight bangs and one clay-orange streak, a thin headset microphone
```

Then the wardrobe of the look, then what she is doing and where. The [character page](https://claudia.gallery/claudia/) has every look's
wardrobe text and the exact wording each film used.

## How the identity text was found

ESCAPE VELOCITY started with a casting call: three hair directions (platinum, black, clay-orange), each as a turnaround,
a catwalk shot and an expression sheet. The black bob with one clay streak won because its silhouette reads at thumbnail
size and the clay stays a small accent.

![The first casting batch: three hair directions, each as a turnaround, a catwalk test and a face sheet. The black bob with one clay streak became Claudia.](https://claudia.gallery/record/escape-velocity/lead-casting-ev01.webp)

Then three ways of holding her identity were tried:

- **Identity passes in an image model** (redrawing each Midjourney plate with her face). They drifted from the Midjourney
  look and refused some poses. The director's note: "Gpt is diverging way too much".
- **Face sheets as image prompts.** A whole sheet imported its multi-head layout; a single face over-conditioned. "Far
  away it gives her big head": a close-up-sized head on a distant figure.
- **Prompt text only.** The canon written into every prompt, plus an explicit descriptor of her ethnicity and skin. This
  is what worked, and every image of her since was made this way.

The face sheets still matter, as a record of who she is. They were never used as the image.

[![Face sheet 3 of the casting batch. With sheet 1 it was picked as her face.](https://claudia.gallery/img/ev-01/lead-black-face-3.m.webp)](https://claudia.gallery/i/ev-01.lead-black-face.3/)

## Distances

Each framing needs a different amount of her. A distance set, the same look in a plain studio from close-up to wide,
shows how much face survives at each scale and which text to use.


[![Close-up](https://claudia.gallery/img/ev-14-dist/dist-cu-2.m.webp)](https://claudia.gallery/i/ev-14-dist.dist-cu.2/)
[![Medium](https://claudia.gallery/img/ev-14-dist/dist-ms-3.m.webp)](https://claudia.gallery/i/ev-14-dist.dist-ms.3/)
[![Full](https://claudia.gallery/img/ev-14-dist/dist-fs-2.m.webp)](https://claudia.gallery/i/ev-14-dist.dist-fs.2/)
[![Wide](https://claudia.gallery/img/ev-14-dist/dist-ws-2.m.webp)](https://claudia.gallery/i/ev-14-dist.dist-ws.2/)


The director's rule: "far away face doesnt matter as much". Wide and extreme wide plates get the short text, or just
the bob, the streak and the look.

## Age

Midjourney's version of her, pale and freckled with a blunt bob and bangs, drifts toward a teenage face: big eyes, a small
chin, a soft jaw. The word "young" makes it worse. ESCAPE VELOCITY's text said "young"; CLODYSSEY and BLISS said "in her
mid-twenties"; plates still came back reading teenage, and were rejected. The current text states her age, 28, and an
adult bone structure, and plates where she reads under about 25 are thrown away before anyone builds on them.

## What changes and what doesn't

The director's brief for the sequel: "keep the exact same character … She can be in different clothes."

| Constant | Can change |
|---|---|
| The black blunt bob and heavy bangs | The wardrobe, completely, per world |
| One clay-orange streak | The light, the grade and the set |
| The clay eight-pointed star clip | Glasses and sunglasses (clay-tinted in BLISS) |
| The headset mic (a boom mic in BLISS) | What she is made of: glass, phone light, chrome, porcelain |
| Pale skin, freckles, dark calm eyes | Her mood: deadpan, persuasive, playful |

CLODYSSEY pushed this furthest. The same head appears as a couture Siren, a ghost of glass and seawater, a hologram of
phone light, a woman in liquid chrome and a colossal porcelain mask, and she is recognisable in each because the bob, the
streak and the clip never move.

![The Siren across the plates: the rocks, the rigging, tied to the mast, and at the rave.](https://claudia.gallery/record/clodyssey/lead-siren.webp)

## When an image reference is right

Once: for the Mask, a colossal porcelain sculpture of her face. A sculpture has to look like her more exactly than a
person in a crowd does, and text alone made a generic face. The Mask prompts used her face sheet and the picked Siren
plate as image prompts, weighted `--iw 0.75` for close shots and `--iw 0.4` for wide ones. Everything else about her
stayed text-only.

## Fixing a plate

A plate that is almost right gets corrected at the source, then everything made from it is re-made:

- **Re-roll** with the same prompt; the other three images of a job are a free pool of variants.
- **Edit with an image model**, with the Midjourney image as the first reference and the prompt listing what must stay
  ("keep her face, hair, streak, clip and the light exactly"). CLODYSSEY corrected 15 plates this way (16 edits, about $2.22):
  a syringe removed, a man's head shaved, a crew re-cast, hooded figures turned into Sirens.
- **Never paint by hand**, and never patch the video frames: a fix in the plate carries into every clip made from it.

![Plate fixes in CLODYSSEY: the Midjourney pick on the left, the image-model correction on the right.](https://claudia.gallery/record/clodyssey/plate-fixes.webp)

## Crowds and bodies

Midjourney tangles limbs and doubles faces when a frame holds many people. Make the set, and her alone in it, in
Midjourney; then add the others with an image-edit model. Check every plate that will feed a video for extra fingers,
a third arm, a doubled face, but don't throw away a bold pose: reject only the unmistakable failures. Once a broken body
goes into a video model, the error moves and gets worse.

## In motion

Seedance 2.5 keeps her when her plate is the first frame. The prompt then states it in plain words:

```prompt
Use @Image1 as the first frame. This first frame defines Claudia's appearance and wardrobe, her pose, the set, the light and the camera direction. Keep Claudia's identity, face, hair with one clay-orange streak, star clip, headset microphone and wardrobe exactly as in @Image1 throughout. Only one Claudia appears. Natural anatomy: natural neck and shoulders, hands with five fingers, no extra or fused fingers, no distorted limbs; normal eyes.
```

What still slips, and has to be checked take by take: Seedance loses her streak on some looks, renders printed fabric
in the wrong colour (the sky-print gown came back lavender), and now and then changes her clothes. Two clips should never
start from the same frame; vary the plate instead. [Seedance](https://claudia.gallery/wiki/seedance/) has the full prompt structure.

## The check before anything is built on a plate

- one streak, clay-coloured, in the bangs
- the star clip and the mic
- an adult face, and the ethnicity in the text
- natural anatomy at 100%
- no text, letters or logos (Midjourney's lettering is garbled; type is drawn in code)
- her look matches the world, with no stray orange
- not a near-duplicate of a plate already used


---
From the Claudia wiki: https://claudia.gallery/wiki/consistency/
