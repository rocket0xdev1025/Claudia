# The storyboard

How a song becomes a hundred shots: the treatment, a through-line device, one explaining graphic per line, the hook, the cut rhythm, her share of the screen, what moves and what it costs, the audit, and the director's review.


The board is where the film gets decided. Each shot carries its time on the song, the lyric it types, the place, what
happens, how the camera answers the music, what moves, and the graphic that explains its line. The plates, the clips,
the edit and the motion design all read from it. The director reviews it as a sheet of cards and leaves notes by shot
id. ESCAPE VELOCITY's board had 141 shots, CLODYSSEY's 94 and BLISS's 44.

## Design before shots

Write these down before any shot:

- **The treatment:** one paragraph on what the film is.
- **The through-line device:** one object that every shot carries and that escalates.
  - ESCAPE VELOCITY: a split-flap board that clatters onto "18 MONTHS TO ESCAPE THE PERMANENT UNDERCLASS", and a LOOK
    counter for the show's looks.
  - CLODYSSEY: a safety card, a rope-load readout in kN and a ×8,192 counter of copies.
  - BLISS: the XP desktop itself, with its windows and the helper's question.
- **The chapter map:** the song's sections grouped into chapters, each with its set, its light and its accent.
- **Plants and payoffs:** the gesture or object of a payoff appears before it is sung.
- **Open questions for the director:** likenesses, taboos, and anything you added yourself.

## A shot

| Field | What |
|---|---|
| time | starts and ends on beats, or on a declared hit |
| lyric | the lines whose words fall in it, and how each is typed |
| set | the place, concretely: "a night market under sodium lamps", not "a market" |
| framing | ECU, CU, MCU, MS, MWS, WS, FS, EWS or OTS |
| action | what happens and the reaction to it, with an end state |
| camera | one move, tied to a sound |
| what moves | a still, a 2.5D plate, a motion clip or a sung clip (below) |
| plate | its prompt: framing first, her identity text, the place, "no text, no letters, no logos" |
| graphics | the explaining graphic and the chrome, each with its timing key |
| transition | a cut, or a motivated device |
| notes | the director's notes on this shot, verbatim |

The full schema is in [Data formats](https://claudia.gallery/wiki/formats/#the-board).

## One explaining graphic per lyric line

For anyone who doesn't know the meme or the myth, the graphic is how the line lands.

1. **It shows what the line means:** the chart the number implies, the interface the joke is about, the diagram of the
   mechanism, the label that classifies the subject, the counter that ticks the stakes.
2. **It is drawn from the thing in frame.** Tally marks are scratched into the mast itself. A clock's own LED segments
   re-light as the number. A meter is read off her actual bow. The director: "as if when you were taking the picture,
   you lined it up perfectly to have the graphics fit, but you put the graphics in in post".
3. **It enters on the word that names it.**
4. **It animates in beats.** Counters roll on sixteenths, rows type one per sixteenth, detections land on
   thirty-seconds, crops cut on eighths.
5. **It escalates across the film**, with its sources on screen in micro-type: dates, "HIS WORDS", "ILLUSTRATIVE
   CURVE".
6. **It is real, not decorative:** numbers, diagrams, labels and interfaces that could exist, and curves that are
   computed. No clip-art.
7. **It reads in one glance on a phone.**

Choose the kind by what the line means:

| The line is | The graphic |
|---|---|
| a number | a counter, chart, tally or gauge |
| a claim or a category | a classifier tag, a label or a stamp |
| a process or a place | a plot, leader lines, a departures board or a spec sheet |
| speech or tech | a chat, a terminal or a voice trace |
| a correction | a strike-through or a redaction |

Use at least six kinds in a film, and never the same kind on three lines in a row.

| Line, as read | Its graphic |
|---|---|
| Ladies. Gentlemen. Agents. | a guest list: LADIES 0% · GENTLEMEN 0% · AGENTS 100%, then a front row of open laptops and no people, each detected as AGENT |
| This is not an AI billboard. | a classifier tag on the billboard flips from BILLBOARD · 0.99 to AI BILLBOARD · 0.97 on "billboard" |
| +25% = −17% | a bar chart drawn on the beat: the weekly limit falls from 150 to 125, "+25%" is struck through, "= −17%" lands in the accent |
| Sorry. Encore. | an APOLOGY METER · VIA BOW gauge read off her actual bow (0° upright, 30° sorry, 60° deep) |
| Feel the AGI | a seismograph: M 9.0 · "FEEL THE AGI" · OFF SCALE |
| Escape velocity: 11.2 KM/S | Newton's cannonball: falls at 7.0, orbits at 7.9, escapes at 11.2 km/s |
| Forty plays. | forty tally marks scratched into the mast |
| You don't have to die. | a hairline of her voice's spectrum flowing into his ear, tagged SOURCE: SIREN ROCK, 2.4 NMI |

A line without a graphic means the board is not done. The exception is a sparse film where the director has asked for
stillness: write that override into the decisions log.

## The hook: the first seconds

People meet the film muted, in a feed, and decide in about a second.

1. **The frame at 1.0 s shows** her face, her streak and one readable line that states the premise. In ESCAPE
   VELOCITY's first frame, her face is in a dark back seat with her eyes closed, a red lamp crosses the clay streak, and
   a full-width split-flap row clatters onto its line and locks on the 1.20 s beat. Her eyes open into the lens on the
   1.12 s hit.
2. **No black frames, and no slow title card first.**
3. **The premise is on screen by 3 s.**
4. **Each bar brings one new piece of information**, and nothing sung appears early. ESCAPE VELOCITY's intro cut once
   per bar: face, scale, profile, destination, a gesture, the arrival.
5. **The first joke lands by about 10 s.**
6. **If the song has a cold open, its words are on screen from 0:00.**
7. **The freeze-frame test:** if the key line can't be read on a phone, enlarge it before changing anything else.

## Cut rhythm

ESCAPE VELOCITY: 141 shots in 306 s, mean 2.17 s, median 1.83 s, about one bar at 131.5 BPM. CLODYSSEY: 94 shots in
190 s, mean about 2.0 s, plus beat-level cuts inside flash and montage shots. ESCAPE VELOCITY by section:

| Section | Mean shot | Why |
|---|---|---|
| intro, no vocal | 1.33 s | the hook: one new thing per bar |
| spoken verse | 1.62 s | jokes, dense |
| sung chorus | 2.69 s | long sung windows: lip sync needs room |
| second verse | 2.63 s | darker, slower |
| bridge | 2.25 s | the countdown |
| drop | 1.58 s | plus eighth-note strobes inside shots |
| outro | 4.40 s | the ring-out |

1. **Every cut lands within 0.03 s of a beat** or a declared hit. If a word would straddle a cut, move the cut by at most
   0.028 s. If it must straddle (a held note), type it in both shots.
2. **Section changes go on downbeats or impacts.**
3. **Match the cut rate to the song's energy, section by section.** Another project put its busiest picture on its
   quietest music and had to be re-animated: "the entire thing is very off pace and off vibe with the song". Its calm
   rebuild ran 0.47 cuts a bar, a 4.0 s mean shot, and straight cuts on bar lines.
4. **Hold longer on sung close-ups**, which need 2–4 s for the lip sync to settle and be checked. Cut faster in spoken
   verses and drops.

## Her share of the screen

- **She is on screen at least 70% of the runtime.** ESCAPE VELOCITY reached 83%. Above 85%, leave room for inserts. A
  second main character can lower it; CLODYSSEY planned 60%.
- **Count honestly:** she counts only when recognisable (face, figure or back view). Hands, boots, tags and props are
  inserts.
- **No stretch without her longer than two bars.**
- **To raise the share, convert prop inserts, not her shots:** put the prop in her hand, or her reflection in it.
- **She sings on camera for most sung words**, in chains of lip-sync windows. In ESCAPE VELOCITY that was 62% of sung
  words, plus 17% of spoken words said straight into the lens.

## What moves, and what it costs

| Tier | What it is | Use when | Cost |
|---|---|---|---|
| still | a plate moved in code (crops on eighths, stills swapped on the beat), or pure motion design | the stillness is the design, or a graphic says it better | free |
| 2.5D | a plate with its depth map, animated with a treatment | most shots that aren't heroes | free |
| motion | a clip from the plate; nobody's mouth forms words | a real turn, a fall, fabric, water, a camera move a still can't give | paid per second |
| sung | a clip with a clean vocal of only her words as the audio reference | she sings or speaks on camera | paid per second, plus covers |

- **Sung windows run 4–8 s**, start in a word gap, and list their exact words. Never more than 8 s of singing in one
  clip. Chain windows with alternating framings, so that a cover cut looks designed.
- **Motion clips run 4–12 s.**
- **One image per shot.** Two clips never start from the same frame: use a sibling candidate, or the previous clip's last
  frame.
- **A 2.5D treatment never repeats on two shots in a row.** It is never a still with a slow zoom. The director: "that's
  where we'll have to shine and be creative. depth to separate layers ofc, motion graphics galore, diversity so its not
  repetitive".
- **The budget:** ESCAPE VELOCITY planned 47 clips (224 s) and generated 421 s. CLODYSSEY planned 101 clips (about 116 s
  sung and 282 s motion). Allow about 60% more sung seconds for divergence covers.

## How the films boarded

ESCAPE VELOCITY's board came from a multi-agent workflow:

- Three director agents boarded the song independently: a fashion film, meme density, and narrative.
- Three judges scored the boards, which came in between 70 and 81; the narrative board won.
- A head director merged the best of the three and checked the merge itself.
- It took about 1.5 hours.

The checks were:

- the shots tile the song;
- the cuts land on beats;
- every line is typed;
- she is on screen enough;
- the clips fit the budget and their windows;
- no image repeats.

A single writer working from the director's walkthrough, with a critic agent behind it, works too. Whichever way you
board, the audit below decides when the board is ready to show.

## The audit

The audit runs after every edit to the board. The board is not sent to the director until every gate passes. (In code:
[What to build](https://claudia.gallery/wiki/toolkit/#9-the-board-file-and-its-audit).)

| Gate | Fails when | Fix |
|---|---|---|
| tile | a gap or an overlap anywhere in the song | extend a neighbour to the shared beat |
| cuts | a cut more than 0.03 s from a beat, and not a declared hit | move it to the nearest beat |
| words typed | a sung word starts in a shot whose type doesn't list its line | add the line, held across the cut in the same mode and position |
| graphics | a lyric line with no explaining graphic | add one |
| lead share | her seconds on screen below the target (default 70%) | convert prop inserts; don't relabel |
| motion budget | planned clip seconds over the budget, or too many clips | demote the weakest motion shots to 2.5D |
| clip windows | a sung window outside 4–8 s or not starting in a word gap; a motion clip outside 4–12 s | move its start into the gap before the first word; copy its words exactly |
| plates unique | one plate on two shots that are not one continuous moment; two clips from one start frame | a sibling candidate, a new plate, or pure motion design |
| banned | a taboo word anywhere in the board | rewrite |
| treatments | a 2.5D shot without a treatment, or the same treatment twice in a row | pick another |
| to do | a placeholder or TODO left, or a shot without a framing | write it |

It also warns, without failing:

- a sung shot whose prompt puts a microphone, a hand or hair in front of her mouth;
- her share above 85%;
- the same transition twice in a row;
- a plate no shot uses;
- a clip that no shot plays.

## The board review

**The sheet.** One card per shot, in order:

- the picked frame, or the first words of the plate prompt if there is no image yet;
- the id, the time and the lyric;
- the framing, the action in one line and what moves;
- the explaining graphic in one line;
- a FACE? badge on any plate whose face may be off-model.

ESCAPE VELOCITY's sheet ran 13 pages of 12 cards, with a cover page showing the chapter map. If the film has a grade,
show graded frames: the director judges what the film will look like.

**The message**, sent once:

```text
The storyboard for <TITLE> is ready: <N> shots, Claudia on screen <X>%, <M> clips (<S> s, about $<E>).
[the board sheet]
Please flag anything by shot id: faces, repeats, boring moments, story logic, colour.
<only if the director set a window:> I'll go ahead in <W> minutes unless you say stop.
Open questions: <…>
```

**The rules:**

1. Silence counts as approval only if the director set the window, and silence never approves spending.
2. While you wait, do only work that costs nothing, such as the plate prompt book and contact sheets.
3. Log every note verbatim against its shot id. Apply every note; when two notes conflict, the later one wins.
4. Re-run the audit. Send the board again only if the director asked to see it. "make all those changes and we're good
   to go" means go ahead.
5. A change after approval makes the approval stale. Say in one line what changed, and ask again.

What the director's notes looked like, and what each one changed:

| Note | What it changed |
|---|---|
| "two seedance videos shouldnt start from teh exact same frame - either use the last frame of the previous video to pick it up, or choose another starting frame" | the distinct-start-frame rule |
| "s058 has a backwards head btw" | a plate re-roll |
| "the boat looks too small compared to s022 / s023." | scale continuity: the plate re-made as a long galley |
| "its kinda bodyslop, need her as a virtual ghost or something, its just two heads next to eachother." | a new idea for the shot, not a re-roll |
| "feel like we could do more with this shot." | a stronger explaining graphic |
| "s034-s036 could use more creativity, kind of a boring moment." | three shots rethought |
| "he needs to have cyberpsychosis still - eyes must be silver again here." | an effect kept continuous across shots |
| "the one saying untie me should actually be the main character woman" | the ending restructured |


---
From the Claudia wiki: https://claudia.gallery/wiki/storyboard/
