---
name: claudia
description: Make images, video and songs with Claudia, the open character from the music videos ESCAPE VELOCITY, CLODYSSEY and BLISS. Use when asked to draw, prompt, animate, sing or write for Claudia, to keep her consistent across shots, or to make a music video the way those films were made (Midjourney plates, Seedance shots with measured lip sync, Suno songs scored for scansion and assonance, storyboards with human checkpoints, motion design drawn in code), including building the tools that pipeline needs.
---

# Claudia

Claudia is the singer of three music videos made with Claude in September and October 2026 (directed by anabology):
ESCAPE VELOCITY, CLODYSSEY and BLISS. She is an AI who looks like a person: a deadpan, curious pop singer with a black
bob, one clay-orange streak, a star clip and a headset mic. Her clothes change with every world; her head never does.
She is an open character: anyone may make work with her (credit "Claudia by anabology" if you can).

The gallery, with every image and its exact prompt: https://claudia.gallery · the wiki: https://claudia.gallery/wiki · MCP server: https://claudia.gallery/mcp

## Her identity: paste it, word for word, into every image prompt

Close and medium shots:

```
a 28-year-old Caucasian American woman with a grown-up angular face, defined cheekbones and a strong jawline, pale skin and light freckles, a glossy black blunt jaw-length bob with heavy straight bangs and one clay-orange streak through the bangs, a small flat clay-orange eight-pointed star hair clip, a thin headset microphone at her cheek
```

Full length and wider (the full text makes Midjourney crop in to her face):

```
a Caucasian American woman in her late twenties with pale skin and a glossy black blunt bob with heavy straight bangs and one clay-orange streak, a thin headset microphone
```

Then her wardrobe for the look, then what she is doing and where. `references/canon.md` has every look's wardrobe text.

## The rules that keep her herself

1. Identity is text, not reference images. Never paraphrase the identity text. No face image references (they
   over-condition: a close-up-sized head on a distant figure), except for things that are not her body, such as a
   porcelain mask of her face.
2. One clay-orange streak (#D97757) through the bangs, on her right side; the star clip on her left; the headset mic.
   No other orange on her.
3. She is a grown woman in her late twenties. Never write "young"; Midjourney drifts her toward a teenage face. Reject
   any image where she reads under about 25.
4. The ethnicity stays in the text; without it Midjourney changed it from shot to shot.
5. Wardrobe changes per world; describe garments, never designers or celebrities.
6. Every prompt ends "no text, no letters, no logos". All type is drawn in code on top.
7. Fix the source, not the frame: re-roll, or correct with an image-edit model (the Midjourney image as the first
   reference, the prompt listing what must stay), then re-make anything built on it. Never paint by hand.
8. Crowds: make the set and her alone in Midjourney, add other people with an edit model.
9. Check every still before a video is made from it: one streak, the clip, the mic, an adult face, natural anatomy,
   no text. Reject only unmistakable failures; keep bold poses.
10. In motion (Seedance 2.5), her plate is the first frame and the prompt says what must stay, in labelled sections.

## A Midjourney prompt, in order

framing → her identity text → wardrobe → action and where she is in the frame → empty space for type, if needed →
the film's style family → "no text, no letters, no logos". Parameters: `--ar 16:9 --v 8.2 --raw --hd` (2:3 for full
length). Keep it under about 800 characters.

Style families: ESCAPE VELOCITY "blue-black #0f1216 and steel blue, one small red lamp as the only warm note, fine
silver-gelatin grain, cinematic 35mm film still"; CLODYSSEY a light state per chapter ("night, moonlight on a black-teal
sea, silver spray, cinematic 35mm film still, anamorphic, fine grain"); BLISS opens "Y2K high fashion editorial, a 2001
couture magazine story:".

## Making a whole film

Read `references/start.md` first. The director (a person) decides at six checkpoints and nowhere else: the concept,
the song by ear, her face on four test plates, the storyboard, the prompts before any spend, and v1. At each one, show
one artefact and ask one question with a default, then record the answer verbatim. Silence never approves spending, a
quality complaint stops all spending, and every fix goes to the source (the prompt or the plate), never the frame.
Between checkpoints the human checks are by eye: faces large, flagged words by ear, contact sheets of rendered frames,
a 5-second sync proof. The tools are not shipped; `references/toolkit.md` specifies each one (the scansion and
assonance scorer, forced alignment and the ear check, the beat map and hits, the board audit, the clean vocal window,
the spectrogram sync check and covers, the edit list, the renderer, the lyric, flash and history checks, the reviewer)
with its constants and the check that says it is done. Their files are in `references/formats.md`.

## Releasing songs with her

- Release under your own name. Never upload as "anabology" (the director's artist profile), and don't present a release
  as official.
- Leave "feat. Claudia" out of the artist field: streaming services would merge it into unrelated artists called Claudia.
- Credit her in the description and on the cover: "Claudia is an open character by anabology (claudia.gallery)".
- If any of it is AI-made (vocals, music or lyrics), say so; human-made work needs no label.
- Make your own songs: don't re-release the songs of ESCAPE VELOCITY, CLODYSSEY or BLISS, or their stems.

The norms in full: `LICENSE.md` ("Songs with her") or https://claudia.gallery/use/#songs-with-her.

## Where to look

| Need | Read |
|---|---|
| Starting a film: checkpoints, accounts, spending, the first conversation | `references/start.md` |
| The full canon, every look, voice, the never-list | `references/canon.md` |
| Keeping her consistent | `references/consistency.md` |
| Writing and picking plates | `references/midjourney.md` |
| Moving shots, the Seedance prompt template, lip sync | `references/seedance.md` |
| Songs: lyrics, Suno style fields, her voice | `references/song.md` |
| The storyboard: shots, explaining graphics, the audit, the review | `references/storyboard.md` |
| Motion design and the edit | `references/motion.md` |
| The whole production, multi-agent lessons, numbers | `references/pipeline.md` |
| The spec of every tool to build, with constants | `references/toolkit.md` |
| The data files the tools share | `references/formats.md` |
| What went wrong, and the rule each failure left | `references/failures.md` |
| Every prompt a film ran, and each film's making-of | `references/films/<film>/<doc>.md` |

Films: `escape-velocity`, `clodyssey`, `bliss`. Docs: `readme`, `prompts-midjourney`, `prompts-seedance`, `prompts-suno`
(and `xp-desktop-and-sound` for bliss). They are long: grep them.

## The gallery from the command line

`scripts/claudia.py` uses only the Python standard library:

```sh
python3 scripts/claudia.py search "porcelain mask"            # rank prompts by words
python3 scripts/claudia.py show sp-02-open.siren-mcu.2          # one image: prompt, params, flags, URLs
python3 scripts/claudia.py list --film bliss --set in_film      # plates in a film
python3 scripts/claudia.py download --film clodyssey --set in_film --size m --out ./claudia-refs
python3 scripts/claudia.py canon                                 # the canon as Markdown
```

Sets: `in_film` (plates used in the finished film), `her` (any image with her), `all`. Sizes: `s` (720 px), `m`
(1800 px), `full` (native). Be polite with downloads: prefer `s` or `m`, and keep what you fetch.
